﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class BolumsController : Controller
    {
        private readonly OkulContext _context;

        public BolumsController(OkulContext context)
        {
            _context = context;
        }

        // GET: Bolums
        public async Task<IActionResult> Index()
        {
            var okulContext = _context.Bolumler.Include(b => b.Fakulte);
            return View(await okulContext.ToListAsync());
        }

        // GET: Bolums/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bolum = await _context.Bolumler
                .Include(b => b.Fakulte)
                .FirstOrDefaultAsync(m => m.BolumID == id);
            if (bolum == null)
            {
                return NotFound();
            }

            return View(bolum);
        }

        // GET: Bolums/Create
        public IActionResult Create()
        {
            ViewData["FakulteID"] = new SelectList(_context.Fakulteler, "FakulteID", "FakulteID");
            return View();
        }

        // POST: Bolums/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BolumID,BolumAd,FakulteID")] Bolum bolum)
        {
            if (ModelState.IsValid)
            {
                _context.Add(bolum);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["FakulteID"] = new SelectList(_context.Fakulteler, "FakulteID", "FakulteID", bolum.FakulteID);
            return View(bolum);
        }

        // GET: Bolums/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bolum = await _context.Bolumler.FindAsync(id);
            if (bolum == null)
            {
                return NotFound();
            }
            ViewData["FakulteID"] = new SelectList(_context.Fakulteler, "FakulteID", "FakulteID", bolum.FakulteID);
            return View(bolum);
        }

        // POST: Bolums/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BolumID,BolumAd,FakulteID")] Bolum bolum)
        {
            if (id != bolum.BolumID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(bolum);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BolumExists(bolum.BolumID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["FakulteID"] = new SelectList(_context.Fakulteler, "FakulteID", "FakulteID", bolum.FakulteID);
            return View(bolum);
        }

        // GET: Bolums/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bolum = await _context.Bolumler
                .Include(b => b.Fakulte)
                .FirstOrDefaultAsync(m => m.BolumID == id);
            if (bolum == null)
            {
                return NotFound();
            }

            return View(bolum);
        }

        // POST: Bolums/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var bolum = await _context.Bolumler.FindAsync(id);
            if (bolum != null)
            {
                _context.Bolumler.Remove(bolum);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BolumExists(int id)
        {
            return _context.Bolumler.Any(e => e.BolumID == id);
        }
    }
}
