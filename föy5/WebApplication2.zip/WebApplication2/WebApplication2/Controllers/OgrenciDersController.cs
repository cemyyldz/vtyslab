﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Models;
using WebApplication2.Data;

namespace WebApplication2.Controllers
{
    public class OgrenciDersController : Controller
    {
        private readonly OkulContext _context;

        public OgrenciDersController(OkulContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(int? yil, string yariyil)
        {
            var ogrenciDersler = _context.OgrenciDersler
                .Include(od => od.Ogrenci)
                .Include(od => od.Ders)
                .AsQueryable();

            if (yil.HasValue)
            {
                ogrenciDersler = ogrenciDersler.Where(od => od.Yil == yil.ToString());
            }

            if (!string.IsNullOrEmpty(yariyil))
            {
                ogrenciDersler = ogrenciDersler.Where(od => od.Yariyil == yariyil);
            }

            ViewBag.Yillar = new SelectList(Enumerable.Range(2020, 7));
            ViewBag.Yariyillar = new SelectList(new List<string> { "Güz", "Bahar" });

            return View(await ogrenciDersler.ToListAsync());
        }

        public async Task<IActionResult> Create()
        {
            ViewBag.Ogrenciler = new SelectList(await _context.Ogrenciler.ToListAsync(), "OgrenciID", "Ad");
            ViewBag.Dersler = new SelectList(await _context.Dersler.ToListAsync(), "DersID", "DersAd");
            ViewBag.Yariyillar = new SelectList(new List<string> { "Güz", "Bahar" });
            ViewBag.Yillar = new SelectList(Enumerable.Range(2020, 7));
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(OgrenciDers ogrenciDers)
        {
            if (ModelState.IsValid)
            {
                _context.Add(ogrenciDers);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            ViewBag.Ogrenciler = new SelectList(await _context.Ogrenciler.ToListAsync(), "OgrenciID", "Ad", ogrenciDers.OgrenciID);
            ViewBag.Dersler = new SelectList(await _context.Dersler.ToListAsync(), "DersID", "DersAd", ogrenciDers.DersID);
            ViewBag.Yariyillar = new SelectList(new List<string> { "Güz", "Bahar" }, ogrenciDers.Yariyil);
            ViewBag.Yillar = new SelectList(Enumerable.Range(2020, 7), ogrenciDers.Yil);
            return View(ogrenciDers);
        }

        public async Task<IActionResult> Delete(int ogrenciID, int dersID)
        {
            var ogrenciDers = await _context.OgrenciDersler
                .FirstOrDefaultAsync(od => od.OgrenciID == ogrenciID && od.DersID == dersID);

            if (ogrenciDers != null)
            {
                _context.OgrenciDersler.Remove(ogrenciDers);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int ogrenciID, int dersID)
        {
            var ogrenciDers = await _context.OgrenciDersler
                .FirstOrDefaultAsync(od => od.OgrenciID == ogrenciID && od.DersID == dersID);

            if (ogrenciDers == null)
            {
                return NotFound();
            }

            ViewBag.Ogrenciler = new SelectList(await _context.Ogrenciler.ToListAsync(), "OgrenciID", "Ad", ogrenciDers.OgrenciID);
            ViewBag.Dersler = new SelectList(await _context.Dersler.ToListAsync(), "DersID", "DersAd", ogrenciDers.DersID);
            ViewBag.Yariyillar = new SelectList(new List<string> { "Güz", "Bahar" }, ogrenciDers.Yariyil);
            ViewBag.Yillar = new SelectList(Enumerable.Range(2020, 7), ogrenciDers.Yil);
            return View(ogrenciDers);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int ogrenciID, int dersID, OgrenciDers ogrenciDers)
        {
            if (ModelState.IsValid)
            {
                // 1. Yeni kombinasyon zaten varsa (başka bir kayıt), hata ver
                var mevcutYeni = await _context.OgrenciDersler
                    .FirstOrDefaultAsync(x => x.OgrenciID == ogrenciDers.OgrenciID && x.DersID == ogrenciDers.DersID);

                if (mevcutYeni != null && (ogrenciDers.OgrenciID != ogrenciID || ogrenciDers.DersID != dersID))
                {
                    ModelState.AddModelError("", "Bu öğrenci bu dersi zaten alıyor.");
                    goto Hazirla;
                }

                // 2. Eski kaydı sil
                var mevcutEski = await _context.OgrenciDersler
                    .FirstOrDefaultAsync(x => x.OgrenciID == ogrenciID && x.DersID == dersID);

                if (mevcutEski == null)
                {
                    ModelState.AddModelError("", "Güncellenecek kayıt bulunamadı.");
                    goto Hazirla;
                }

                try
                {
                    _context.OgrenciDersler.Remove(mevcutEski);
                    await _context.SaveChangesAsync();

                    _context.OgrenciDersler.Add(ogrenciDers);
                    await _context.SaveChangesAsync();

                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", "Veritabanı hatası: " + ex.Message);
                }
            }

        Hazirla:
            ViewBag.Ogrenciler = new SelectList(await _context.Ogrenciler.ToListAsync(), "OgrenciID", "Ad", ogrenciDers.OgrenciID);
            ViewBag.Dersler = new SelectList(await _context.Dersler.ToListAsync(), "DersID", "DersAd", ogrenciDers.DersID);
            ViewBag.Yariyillar = new SelectList(new List<string> { "Güz", "Bahar" }, ogrenciDers.Yariyil);
            ViewBag.Yillar = new SelectList(Enumerable.Range(2020, 7), ogrenciDers.Yil);
            return View(ogrenciDers);
        }

        public async Task<IActionResult> OgrenciDersleri(int? ogrenciID)
        {
            if (!ogrenciID.HasValue)
            {
                ViewBag.Hata = "Lütfen geçerli bir öğrenci ID'si giriniz.";
                return View(new List<OgrenciDers>());
            }

            var ogrenci = await _context.Ogrenciler
                .FirstOrDefaultAsync(o => o.OgrenciID == ogrenciID);

            if (ogrenci == null)
            {
                ViewBag.Hata = "Girilen ID'ye ait öğrenci bulunamadı.";
                return View(new List<OgrenciDers>());
            }

            var dersler = await _context.OgrenciDersler
                .Include(od => od.Ders)
                .Where(od => od.OgrenciID == ogrenciID)
                .ToListAsync();

            ViewBag.OgrenciAd = ogrenci.Ad;
            ViewBag.OgrenciID = ogrenciID;

            return View(dersler);
        }

        public async Task<IActionResult> NotGiris(int dersID)
        {
            var ogrenciDersler = await _context.OgrenciDersler
                .Include(od => od.Ogrenci)
                .Include(od => od.Ders)
                .Where(od => od.DersID == dersID)
                .ToListAsync();

            return View(ogrenciDersler);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> NotGiris(List<OgrenciDers> ogrenciDersler)
        {
            if (ModelState.IsValid)
            {
                foreach (var item in ogrenciDersler)
                {
                    var mevcut = await _context.OgrenciDersler
                        .FirstOrDefaultAsync(x => x.OgrenciID == item.OgrenciID && x.DersID == item.DersID);

                    if (mevcut != null)
                    {
                        mevcut.Vize = item.Vize;
                        mevcut.Final = item.Final;
                        _context.Update(mevcut);
                    }
                }

                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(ogrenciDersler);
        }
    }
}
