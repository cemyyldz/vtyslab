using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication2.Views.OgrenciDers
{
    public class NotGirisModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
