﻿namespace WebApplication2.Models
{
    public class OgrenciDers
    {
        public int OgrenciID { get; set; }
        public int DersID { get; set; }
        public string? Yil { get; set; }
        public string? Yariyil { get; set; }
        public int? Vize { get; set; }
        public int? Final { get; set; }

        public Ogrenci? Ogrenci { get; set; }
        public Ders? Ders { get; set; }
    }
}
