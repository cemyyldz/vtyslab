﻿namespace WebApplication2.Models
{
    public class Ders
    {
        public int DersID { get; set; }
        public string? DersAd { get; set; }

        public ICollection<OgrenciDers>? OgrenciDersler { get; set; }
    }
}
